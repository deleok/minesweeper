from mineSweeper import Minesweeper
import unittest
from unittest import mock
from unittest import TestCase


class MinesweeperTest(unittest.TestCase):
    def test_1_1_with_mine(self):
        field_to_test = Minesweeper().create_solution()
        self.assertEqual(field_to_test, 0, "Area should be 0")

# class DictCreateTests(TestCase):
#     @mock.patch('module_under_test.input', create=True)
#     def testdictCreateSimple(self, mocked_input):
#         mocked_input.side_effect = ['Albert Einstein', '42.81', 'done']
#         result = dictCreate(1)
#         self.assertEqual(result, {'Albert Einstein': [42.81]})


# class MinesweeperTest(TestCase):
#     @mock.patch('mineSweeper.py', create=True)  # module_under_test.input
#     def test_1_1_with_mine(self, mocked_input):
#         mocked_input.side_effect = ["4 4\n*"]
#         result = Minesweeper().create_solution()
#         self.assertEqual(result, {"Field #1:\n *"})



    # f = open("minesweeper_input.txt", "r")
    # f2 = open("minesweeper_output.txt", "r")
    #
    #
    # def test_1_1_with_mine(self):
    #     input_to_test = Minesweeper.create_solution()



    # f.close()
    # f2.close()


if __name__ == '__main__':
    unittest.main()