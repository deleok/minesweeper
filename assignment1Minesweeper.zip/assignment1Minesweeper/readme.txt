Team 4 Minesweeper

Kara de Leon
  - Time to complete: ~5 hours (less time spent due to being sick)
  - Shortcomings: My individual solution produced '.' for some hints on the second board and had difficulty reading input from the console.

Kishan Vekaria
  - Time to complete: 15 hours
  - Shortcomings: My output file generates two blank lines at the end of output.

Qibai Zhu
  - Time to complete: 8 hours
  - Shortcomings: My output file generates two blank lines at the end of output.