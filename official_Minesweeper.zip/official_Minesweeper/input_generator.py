"""
Kishan Vekaria

This program is given input and creates Minesweeper games. Those games are written to minesweeper_input.txt
"""

import random


class InputGenerator:

    def create_minesweeper_input(self):
        """
        Takes user input to create minefields
        :return: writes minefield games to minesweeper_input.txt
        """
        f = open("minesweeper_input.txt", "w")

        user_input = ""
        condition = True
        while condition:
            user_input = input("Size of minefield (rows columns) Entering \"0 0\" will stop input: ")
            minefield_size = user_input
            if user_input == "0 0":
                break

            row_and_col = minefield_size.split(" ")  # splitting input using the "space" in between the two numbers
            rows = int(row_and_col[0])  # first number determines number of rows
            cols = int(row_and_col[1])  # second number determines number of columns
            f.write(str(rows) + " " + str(cols) + "\n")

            percent_of_mines = int(input("Percent of mines (0-100): "))

            for i in range(rows):
                row = []
                for j in range(cols):
                    mine_number = random.randint(1, 100)
                    if mine_number <= percent_of_mines:
                        f.write("*")
                    else:
                        f.write(".")
                f.write("\n")

        f.write("0 0")
        f.close()


if __name__ == '__main__':
    InputGenerator().create_minesweeper_input()


""" Input text for inputGenerator"""
# 1 1
# 100
# 1 1
# 0
# 100 100
# 100
# 100 100
# 0
# 100 100
# 35
# 1 100
# 100
# 1 100
# 0
# 1 100
# 75
# 100 1
# 100
# 100 1
# 0
# 100 1
# 20
# 4 4
# 50
# 2 2
# 25
# 3 9
# 70
# 0 0
